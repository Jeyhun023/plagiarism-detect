__version__ = "0.3.0"

from .detector import CopyDetector, CodeFingerprint, compare_files
